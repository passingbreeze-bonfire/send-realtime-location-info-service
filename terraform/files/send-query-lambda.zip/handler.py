import boto3
import json
import requests
from requests_aws4auth import AWS4Auth
import os
import mpu
from decimal import *

region = 'ap-northeast-2'
service = 'es'
credentials = boto3.Session().get_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

host = os.environ.get("OPENSEARCH_DOMAIN") # The OpenSearch domain endpoint with https://
index = os.environ.get("OPENSEARCH_INDEX")
opensearch_url = host + '/' + index + '/_search' # openSearch URL
destination_url = os.environ.get("DESTINATION_URL") # 고객에게 전송

# DynamoDB
resource = boto3.resource('dynamodb')
table = resource.Table(os.environ.get("DB_TABLE_NAME"))
client = boto3.client('apigatewaymanagementapi', endpoint_url=destination_url)
dynamodb_index=0
# Error Handling -> 'TypeError: Object of type Decimal is not JSON serializable'
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        # 👇️ if passed in object is instance of Decimal
        # convert it to a string
        return str(obj) if isinstance(obj, Decimal) else json.JSONEncoder.default(self, obj)

# Lambda execution starts here
def lambda_handler(event, context):
  resp = table.scan()
  trucks = resp['Items']

  for truck in trucks:
    query = { 
      "size" : 1,
      "sort" : [
        { "timestamp": { "order" : "desc" , "unmapped_type" : "long"} }
      ],
      "query": {
        "match": {
            "truckId" : truck['matched_truckid']
        }
      }
    }
    headers = { "Content-Type": "application/json" }
    r = requests.get(opensearch_url, auth=awsauth, headers=headers, data=json.dumps(query, cls=DecimalEncoder))

    # Create the response and add some extra content to support CORS
    response = {
        "statusCode": 0,
        "headers": {
            "Access-Control-Allow-Origin": '*',
            "Content-Type": "application/json"
        },
        "isBase64Encoded": False
    }
    # Add the search results to the response
    if (200 <= r.status_code < 400):
      payload = { }
      full_res = json.loads(r.text)
      res_truck = full_res['hits']['hits'][0]['_source']

      cur = { }
      cur['lon'] = res_truck['lon']
      cur['lat'] = res_truck['lat']

      dest = { }
      dest['lon'] = truck['to_lon']
      dest['lat'] = truck['to_lat']
    else:
      response['statusCode'] = r.status_code
      response['body'] = "Failed to access opensearch"
      return response

    res_truck['arrive'] = chk_arrive(cur, dest)
    payload['text'] = json.dumps(res_truck)
    dr = requests.post(destination_url, json=payload, headers=headers)
    response['statusCode'] = dr.status_code    
    return response

# Check if the truck has arrived
def chk_arrive(cur, dest, dist_range=0.02):
    dist = mpu.haversine_distance((cur['lat'], cur['lon']), (dest['lat'], dest['lon']))
    return dist_range > dist